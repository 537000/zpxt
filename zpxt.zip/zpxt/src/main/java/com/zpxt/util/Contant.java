package com.zpxt.util;

public class Contant {

	// 招聘状态为已发布
	public static final int ZP_STATE = 2;
	// 员工状态为在职
	public static final int YG_ZZ = 1;
	// 员工状态为离职申请中
	public static final int YG_LZSQ = 99;
	// 员工状态为离职
	public static final int YG_LZ = 2;
	// 员工状态为试用期
	public static final int YG_SX = 3;
	// 面试状态为应聘通过
	public static final int YP_TG = 1;
	// 面试状态为应聘不通过
	public static final int YP_BTG = -1;
	// 面试状态为面試通过
	public static final int MS_TG = 2;
	// 面试状态为不通过
	public static final int MS_BTG = -2;
}
