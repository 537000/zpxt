/**
 * 
 */
//	$(window).ready(function() {
//			//var screenH = document.documentElement.clientHeight || document.body.clientHeight;
//			//$('.container').css({
//			//	height : screenH
//			//});
//		 });
//	$(document).ready(function() { 
//		var screenH = document.documentElement.clientHeight || document.body.clientHeight;
//		   $('.container').css({
//			 height : screenH
//		   });
//	}); 
	$(window).ready(function() {
		var screenH = document.documentElement.clientHeight || document.body.clientHeight;
	   $('#container').css({
			 height : screenH
	   });
	});